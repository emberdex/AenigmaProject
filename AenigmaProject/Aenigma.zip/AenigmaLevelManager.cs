﻿using System;
using System.Collections.Generic;
using System.IO;

namespace AenigmaProject
{
    public class AenigmaLevelManager
    {
        private static List<AenigmaLevel> levels = new List<AenigmaLevel>();

        /// <summary>
        /// Adds a level to the list.
        /// </summary>
        /// <param name="level">The level to add to the list.</param>
        /// <exception cref="NullReferenceException">Thrown if a null level, or a level with a GUID equivalent to Guid.Empty, is passed in.</exception>
        public static void InsertLevel(AenigmaLevel level)
        {
            if (level?.ID != Guid.Empty)
            {
                levels.Add(level);
            }
            else
            {
                throw new NullReferenceException("Tried to add an empty or NULL level to the list.");
            }
        }

        /// <summary>
        /// Removes a level from the list.
        /// </summary>
        /// <param name="id">The level to remove, by GUID.</param>
        /// <exception cref="LevelNotFoundException">Thrown if a level with the specified GUID is not found.</exception>
        public static void RemoveLevel(Guid id)
        {
            if (id != Guid.Empty)
            {
                foreach (AenigmaLevel level in levels)
                {
                    if (level?.ID == id)
                    {
                        levels.Remove(level);
                    }
                }
            }
            
            throw new LevelNotFoundException("A level with the specified GUID could not be found.");
        }
        
        /// <summary>
        /// Function to find a level in the list with a specific GUID.
        /// </summary>
        /// <param name="id">The GUID to match against.</param>
        /// <returns>The level matching the GUID.</returns>
        /// <exception cref="LevelNotFoundException">Thrown if a level with the specified GUID is not found.</exception>
        public static AenigmaLevel GetLevelById(Guid id)
        {
            foreach (AenigmaLevel level in levels)
            {
                if (level.ID.Equals(id)) return level;
            }
            
            throw new LevelNotFoundException("A level with the specified GUID could not be found.");
        }
        
        /// <summary>
        /// Loads levels from a given directory.
        /// </summary>
        /// <param name="path">The path to load levels from.</param>
        /// <exception cref="LevelLoadException">Thrown if an error occurs while loading levels.</exception>
        public static void LoadLevelsFromDirectory(String path)
        {
            if (Directory.Exists(path))
            {
                foreach(string file in Directory.EnumerateFiles(path))
                {
                    Console.WriteLine(file);
                }
            }
            else
            {
                throw new LevelLoadException("The specified path does not exist.");
            }
        }      
    }
}