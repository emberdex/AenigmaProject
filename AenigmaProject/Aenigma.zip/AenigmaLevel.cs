﻿using System;
using System.Drawing;

namespace AenigmaProject
{
    public enum AenigmaLevelType
    {
        Level, Cutscene
    }
    
    public class AenigmaLevel
    {
        public Guid ID;
        public AenigmaLevelType LevelType;
        public string Password;
        public string Data;
        public string CorrectAnswer;
        public Point CursorCoords;
        public Guid NextStage;
        public Guid FailedStage;
        public bool IsFinalStage;

        public AenigmaLevel()
        {
            
        }

        public AenigmaLevel(Guid id, AenigmaLevelType type, string password, string data, string correctAnswer,
            Point cursorCoords, Guid nextStage, Guid failedStage, bool isFinalStage)
        {
            this.ID = id;
            this.LevelType = type;
            this.Password = password;
            this.Data = data;
            this.CorrectAnswer = correctAnswer;
            this.CursorCoords = cursorCoords;
            this.NextStage = nextStage;
            this.FailedStage = failedStage;
            this.IsFinalStage = isFinalStage;
        }
    }
}