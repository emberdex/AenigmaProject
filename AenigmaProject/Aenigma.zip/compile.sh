#!/bin/bash
xbuild /p:Configuration=Release AenigmaProject.csproj
