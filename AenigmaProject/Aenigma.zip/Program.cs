﻿using System;
using System.Collections.Generic;

namespace AenigmaProject
{
    internal class Program
    {
        public static String LevelPath = "stages/";
        
        public static void Main(string[] args)
        {
            Console.WriteLine("Initialising Project Aenigma...");

            if (args.Length > 1)
            {
                LevelPath = args[1];
            }
            
            Console.WriteLine($"Reading levels from {LevelPath}.");

            AenigmaLevelManager.GetLevelById(Guid.Empty);
        }
    }
}